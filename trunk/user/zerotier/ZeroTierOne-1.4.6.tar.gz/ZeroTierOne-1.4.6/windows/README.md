This folder contains the Windows driver code, Windows-specific service code, and the Microsoft Visual Studio projects and "solution" for doing Windows builds.

This code may also build with MinGW but this hasn't been tested.
